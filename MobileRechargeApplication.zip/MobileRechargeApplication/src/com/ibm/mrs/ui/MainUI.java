package com.ibm.mrs.ui;

import java.math.BigDecimal;
import java.util.Scanner;

import com.ibm.mra.beans.Account;

public class MainUI {
	public static void main(String[] args)
	{
		MainUI ob = new MainUI();
		while(true)
		{
			ob.menu();
		}
	}
	void menu()
	{
		System.out.println("pLease ennter your choice\n");
		System.out.println("1-Account Balance enquiry\n");
		System.out.println("2-Recharge account\n");
		System.out.println("3-Exit\n");
		Scanner sc=new Scanner(System.in);
		int option=sc.nextInt();
		switch(option)
		{
		case 1:
		{
			System.out.println("Please enter your phone number\n");
			String mob = sc.next();
			try {
			   // Account acc1=pk.displayBalance(mob);
				// System.out.println("Your Current Balance is:"+acc1.getAccountBalance());
			   }
			   catch(Exception e)
			   {   
				  System.out.println("Given account does not exists\n"); 
			   }

			  break;
			
		}
		case 2:
		{
			System.out.println("please enter your mobile no");
			String dmob=sc.next();
			System.out.println("Enter the recharge ammount\n");
			double dbalance=sc.nextDouble();
			try {
			//Account acc=pk.recharge(dmob, dbalance);
			//System.out.println("Balance after depositing is"+acc.getAccountBalance());
			}
			catch(Exception e)
			{System.out.println("Cannot recharge the amount as the mobile number does not exist\n");}
			break;

			
		}
		case 3:
		{
			System.out.println("you have closed application\n");
			break;
		}
		default: System.out.println("you have entered the wrong choice");
		}
		
	}
	

}
