package com.ibm.mra.dao;

import java.util.HashMap;

import com.ibm.mra.beans.Account;
import com.sun.javafx.collections.MappingChange.Map;

public class AccountDaoImpl implements AccountDao {
	 java.util.Map<String, Account> data; 
		public AccountDaoImpl(java.util.Map<String, Account> data2) {
			super();
			this.data = data2;
		}

		public boolean save(Account account) 
		{
			Account account1=null;
		account1=findOne(account.getMobileNo());
			if(account1==null)
			{
				data.put(account.getMobileNo(),account);
				return true;
			}
			else
			{
				data.put(account.getMobileNo(),account);
				return true;
			}
			
		}
		public Account findOne(String mobileNo) 
		{
//		if (data.containsKey(mobileNo))
//				{
//			
//			  return (data.get(mobileNo));
//			
//				}
//		else {
		return null;	
		}



		@Override
		public Account getAccountDetails(String mobileNo) {
			// TODO Auto-generated method stub
			return null;
}

		@Override
		public int rechargeAccount(String mobileNo, double rechargeAmount) {
			// TODO Auto-generated method stub
			return 0;
	}
