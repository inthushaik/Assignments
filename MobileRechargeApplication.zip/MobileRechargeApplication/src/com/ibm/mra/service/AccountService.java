package com.ibm.mra.service;

import com.ibm.mra.beans.Account;

public interface AccountService {
public Account getAccountDetails(String mobileNo);
public int rechargeAccount(String mobileNo, double rechargeAmount);
}
