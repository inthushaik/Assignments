package com.ibm.mra.service;

import java.math.BigDecimal;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.ibm.Exception.InvalidInputException;
import com.ibm.Exception.MobileNumberNotRegistered;
import com.ibm.mra.beans.Account;
import com.ibm.mra.dao.AccountDao;
import com.ibm.mra.dao.AccountDaoImpl;

public class AccountServiceImpl implements AccountService{
	private AccountDao dao;

	public AccountServiceImpl(Map<String, Account> data){
		dao = new AccountDaoImpl(data);
	}
	public AccountServiceImpl(AccountDao dao) {
		super();
		this.dao = dao;
	}

	public AccountServiceImpl() 

{		

	super();	
}


	@Override
	public Account getAccountDetails(String mobileNo) {
		Pattern p=Pattern.compile("[0-9]{10}");
		Matcher m=p.matcher(mobileNo);
		if(m.find()&& m.group().equals(mobileNo))
		{	
		               Account account=null;
			         account = dao.findOne(mobileNo);
		                   if(account!=null)
			                 return account;
		                    else
		                	throw new MobileNumberNotRegistered("your mobile number not registered");
		}
		else
		{
			throw new InvalidInputException("please correctly enter 10 digit mobile number");
		}
		
		//return null;
	}

	@Override
	public int rechargeAccount(String mobileNo, double rechargeAmount) {
		Pattern pattern=Pattern.compile("[0-9]{10}");
		Matcher m=pattern.matcher(mobileNo);
		if(m.find()&& m.group().equals(mobileNo))
		{
		Account acc1 =null;
		
			acc1=dao.findOne(mobileNo);
		
		 if(acc1==null)
		    
		    	throw new MobileNumberNotRegistered(" mobile Number is not registered");
		 else
		 {
		double p1=acc1.getAccountBalance();
		p1=p1.add(amount);
		Account ob=new Account(mobileNo, mobileNo, p1);
		acc1.Account(ob);
		
		dao.save(acc1);
		return acc1;
		 }
		}
		else
		{
			
			throw new InvalidInputException("please correctly enter 10 digit mobile number");
		}
		return 0;
	}

}
