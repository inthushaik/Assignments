package com.ibm.mra.beans;

public class Account {
	private String accountType;
	private String MobileNo;
	private String customerName;
	private double accountBalance;
	public Account(String accountType2, String customerName2, double accountBalance2 ) {
	this.customerName = customerName2;
	accountType = accountType2;
	accountBalance = accountBalance2;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public double getAccountBalance() {
		return accountBalance;
	}
	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}
	@Override
	public String toString() {
		return "Customer name=" + customerName + ", Account Type is" + accountType + "Account Balance"+accountBalance;
	}
	
	public String getMobileNo() {
		return MobileNo;
	}
	public void setMobileNo(String mobileNo) {
		MobileNo = mobileNo;
	}
	

}
